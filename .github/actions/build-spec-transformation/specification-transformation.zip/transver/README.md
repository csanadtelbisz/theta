<!--
This file is part of TransVer,
a tool for transforming verification tasks:
https://gitlab.com/sosy-lab/software/transver

SPDX-FileCopyrightText: 2024 Dirk Beyer

SPDX-License-Identifier: Apache-2.0
-->

# TransVer

## Setup

This tool has some external dependencies that need to be setup before running it. 
This can be done by running the following command:

```bash
make setup
```

## Command Line Use

Supported transformations are:
- termination -> reachability
- termination-with-counters -> reachability
- overflow -> reachability
- memory-cleanup -> reachability
- one-step-reachability -> reachability

Command line to run the transformation of a single line:
```bash
python transver.py --from-property <property> --to-property reachability --algorithm InstrumentationOperator <program>
```

## Witness Transformation

Supported transformations are:
- reachability -> termination 
Command line:
```bash
python transver.py --from-property reachability --to-property termination --original-program <program> --algorithm R2TWitness <witness>
```
