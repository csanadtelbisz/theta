<!--
This file is part of TransVer,
a tool for transforming verification tasks:
https://gitlab.com/sosy-lab/software/transver

SPDX-FileCopyrightText: 2024 Dirk Beyer

SPDX-License-Identifier: Apache-2.0
-->

# Dependencies

This project currently has the following dependencies:
* CPAchecker

They can all be installed by following the steps in the
[README](../README.md) of the root directory of this project.
